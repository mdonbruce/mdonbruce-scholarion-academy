SCHOLARION INITIAL DEVELOPMENT v0.1

Open index.html in a modern browser.

Included in this initial standalone prototype:
- Scholarion-only branding
- Public platform shell
- Platform module architecture
- Scholarion Scenario-Based Learning framework
- Catalog/pathway preview
- Learner, Faculty, and Admin workspace previews
- Credential automation preview

This is an initial UI/product shell. Persistent authentication, databases, gradebook, labs, credential issuance, email, and AI services are subsequent implementation stages.
