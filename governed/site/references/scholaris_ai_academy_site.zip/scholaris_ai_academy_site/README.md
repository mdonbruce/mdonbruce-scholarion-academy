# Scholaris AI Academy Website

Static, responsive website prototype for Scholaris AI Academy.

## Included
- Scholaris AI Academy SVG logo
- Responsive homepage
- 11 program catalog cards loaded from JSON
- Track filters
- Program detail modal
- Learning experience, stackability, credential, responsible-AI, career-support, FAQ, and application sections
- Credential-integrity language that avoids accreditation/degree claims
- WCAG-minded structure and keyboard-accessible modal/menu basics

## Run locally
From this folder:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000`.

## Production notes
- Replace `admissions@scholaris.example` with a real admissions email or form endpoint.
- Wire Apply buttons to Scholaris authentication/admissions.
- Replace demo/fallback visual treatment with approved brand photography if desired.
- Add CMS or Scholaris API integration for dynamic catalog, applications, and learner portal.
