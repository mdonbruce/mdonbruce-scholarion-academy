let programs=[];
const grid=document.querySelector('#programGrid');
const modal=document.querySelector('#programModal');
const modalBody=document.querySelector('#modalBody');
const filters=document.querySelectorAll('.filter');

async function loadPrograms(){
  programs=await fetch('data/programs.json').then(r=>r.json());
  renderPrograms(programs);
}
function renderPrograms(items){
  grid.innerHTML=items.map(p=>`<article class="program-card" data-track="${p.track}">
    <div class="program-meta"><span class="pill">${p.track}</span><span class="pill">${p.length}</span></div>
    <h3>${p.title}</h3><p>${p.summary}</p>
    <div class="program-meta"><span class="pill">${p.coding}</span></div>
    <div class="actions"><button class="btn btn-secondary" onclick="openProgram(${p.id})">Program details</button><a class="btn btn-primary" href="#apply">Apply</a></div>
  </article>`).join('');
}
window.openProgram=function(id){
  const p=programs.find(x=>x.id===id);
  modalBody.innerHTML=`<div class="modal-head"><div><span class="pill">${p.track} · ${p.length}</span><h2>${p.title}</h2></div><button class="close" aria-label="Close program details" onclick="closeModal()">×</button></div><p>${p.summary}</p><p><strong>Coding level:</strong> ${p.coding}</p><div class="capstone"><strong>Capstone direction</strong><p>${p.capstone}</p></div><p><strong>Credential:</strong> Scholaris AI Academy Certificate of Completion / Professional Certificate, as applicable.</p><p><strong>Learning experience:</strong> hands-on modules, labs, projects, assessments, digital credential, and career-services hooks.</p><a class="btn btn-primary" href="#apply" onclick="closeModal()">Start application</a>`;
  modal.classList.add('open');modal.setAttribute('aria-hidden','false');
};
window.closeModal=function(){modal.classList.remove('open');modal.setAttribute('aria-hidden','true')};
modal.addEventListener('click',e=>{if(e.target===modal)closeModal()});
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeModal()});
filters.forEach(btn=>btn.addEventListener('click',()=>{filters.forEach(b=>b.classList.remove('active'));btn.classList.add('active');const f=btn.dataset.filter;renderPrograms(f==='All'?programs:programs.filter(p=>p.track===f));}));
document.querySelector('.menu-btn').addEventListener('click',()=>document.querySelector('.nav').classList.toggle('mobile-open'));
loadPrograms();
