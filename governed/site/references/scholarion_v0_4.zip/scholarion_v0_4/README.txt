Scholarion v0.4
- Restores approved public cover page as /
- Separates public site from LMS application
- Adds Learner, Faculty, Admin, LMS Overview, Login routes
- Preserves Proctored Assessment Setup support
- Scholarion-only branding
