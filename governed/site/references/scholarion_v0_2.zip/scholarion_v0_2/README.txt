Scholarion v0.2
Interactive standalone front-end prototype.
Includes approved blue/white Scholarion identity, LMS dropdown, Learner/Faculty/Admin role workspaces, catalog/pathway/SBL/credential surfaces.
Backend persistence/authentication is not yet implemented.
